%{
dataforstress
figure()
[Rsq,period,scale,coi,sig95,t]=rau13(data(:,1),data(:,2));
Yticks = 2.^(fix(log2(min(period))):fix(log2(max(period))));
contourf(t,log2(period),Rsq,12);%#ok       
set(gca,'clim',[-1 1])      
set(gca,'YLim',log2([min(period),max(period)]), ...
    'YDir','reverse', 'layer','top', ...
    'YTick',log2(Yticks(:)), ...
    'YTickLabel',num2str(Yticks'), ...
    'layer','top')
     ylabel('Period')
colorbar


%}

%% House-keeping
clear
close all
s = RandStream('mcg16807','Seed',0);
RandStream.setDefaultStream(s);
%randn('seed',0)
%% Setting parameters

a=[-0.5 0.1 0.5];
b=0;
lb=300;
ub=350;
%% Building the model
one=ones(4,1);
rho=0;
Sig=[0.1 rho;
     rho 0.01];
nobs=200;
nburns=200;
e1=mvnrnd([0 0],Sig,nobs+nburns)';
e=[e1;zeros(2,nobs+nburns)];
y1=e(:,1);

indx=0;

A1=[0.1     0   0.1     0;
      0   0.1     0     0;
      1     0     0     0;
      0     1     0     0];
  
A2=[0.1     0   0.1     0;
      0   0.1   -1    0.1;
      1     0     0     0;
      0     1     0     0];

for t = 2:nobs+nburns
    if t>=lb & t<ub
    y1(:,t)=A2*y1(:,t-1)+e(:,t);
    else 
    y1(:,t)=A1*y1(:,t-1)+e(:,t);
    end
end
data=y1(:,nburns+1:end)';
indx=indx+1;
l=1;m=2;
%titl=['a = ' num2str(a(i)) '; b =' num2str(b)];
set(gcf,'pos',get(gcf,'pos').*[1 .2 1.2 2])
if indx==5,xta=1; else xta=0; end;
figure('color',[1 1 1])
wavecausalplot([data(:,l)],[data(:,m)],'xLeadyInPhase',xta);

figure('color',[1 1 1])
wavecausalplot([data(:,l)],[data(:,m)],'xLeadyAntiPhase',xta);

figure('color',[1 1 1])
wavecausalplot([data(:,l)],[data(:,m)],'xLeady',xta);
