function varargout=wt(d,I,J,varargin)
%% Continous Wavelet Transform
% Creates a figure of wavelet power in units of
% normalized variance.
%
% USAGE: [wave,period,scale,coi,sig95]=wt(d[,params])
% 
% d: a time series
% wave: the wavelet transform of d
% period: a vector of "Fourier" periods associated with wave
% scale: a vector of wavelet scales associated with wave
% coi: the cone of influence
%
% Settings: Pad: pad the time series with zeros? 
% .         Dj: Octaves per scale (default: '1/12')
% .         S0: Minimum scale
% .         J1: Total number of scales
% .         Mother: Mother wavelet (default 'morlet')
% .         MaxScale: An easier way of specifying J1
% .         MakeFigure: Make a figure or simply return the output.
% .         BlackandWhite: Create black and white figures
% .         AR1: the ar1 coefficient of the series 
% .              (default='auto' using a naive ar1 estimator. See ar1nv.m)
%
% Settings can also be specified using abbreviations. e.g. ms=MaxScale.
% For detailed help on some parameters type help wavelet.
%
%
% Example:
%      wt([0:200;sin(0:200)],'dj',1/20,'bw','maxscale',32)
%
% (C) Aslak Grinsted 2002-2004
%
% http://www.pol.ac.uk/home/research/waveletcoherence/

% -------------------------------------------------------------------------
%   Copyright (C) 2002-2004, Aslak Grinsted
%   This software may be used, copied, or redistributed as long as it is not
%   sold and this copyright notice is reproduced on each copy made.  This
%   routine is provided as is without any express or implied warranties
%   whatsoever.

global timeunit
% ------validate and reformat timeseries.
[d,dt]=my_formatts(d,timeunit);
d=d(:,2:end);
n=size(d,1);

%----------default arguments for the wavelet transform-----------
Args=struct('Pad',1,...      % pad the time series with zeroes (recommended)
            'Dj',1/12, ...    % this will do 12 sub-octaves per octave
            'S0',2*dt,...    % this says start at a scale of 2 years
            'J1',[],...
            'Mother','Morlet', ...
            'MaxScale',[],...   %a more simple way to specify J1
            'BlackandWhite',0,...
            'AR1','auto');
Args=parseArgs(varargin,Args,{'BlackandWhite'});
if isempty(Args.J1)
    if isempty(Args.MaxScale)
        Args.MaxScale=(n*.17)*2*dt; %automaxscale
    end
    Args.J1=round(log2(Args.MaxScale/Args.S0)/Args.Dj);
end

if strcmpi(Args.AR1,'auto')
    Args.AR1=ar1nv(d(:,2));
    if any(isnan(Args.AR1))
        error('Automatic AR1 estimation failed. Specify it manually (use arcov or arburg).')
    end
end

%----------------::::::::---------- Analyze: ---------:::::::::::::-----------------
[Wxy,period,scale,coi,nx,sinv]=filterdata(d,I,J,dt,Args);
Wxx=filterdata(d,I,I,dt,Args);
Wyy=filterdata(d,J,J,dt,Args);
sWxy=smoothwavelet(sinv(:,ones(1,nx)).*Wxy,dt,period,Args.Dj,scale);
sY=smoothwavelet(sinv(:,ones(1,nx)).*abs(Wxx).^2,dt,period,Args.Dj,scale);
sX=smoothwavelet(sinv(:,ones(1,nx)).*abs(Wyy).^2,dt,period,Args.Dj,scale);
Rua=real(sWxy)./sqrt(sX.*sY);
Rua(sX<=1e-10)=0;
Rua(sY<=1e-10)=0;
Rsq=Rua.*sqrt(sY)./sqrt(sX);
Rsq(sX<=1e-10)=0;
t=d(:,1);
 cohesionplot(Rsq,period,t)
varargout={Rsq,period,scale,coi,t};
varargout=varargout(1:nargout);


function cohesionplot(Rsq,period,t,xlab)
Yticks = 2.^(fix(log2(min(period))):fix(log2(max(period))));
contourf(Rsq); 
%set(gca,'clim',[-1 1])      

set(gca,'YLim',log2([min(period),max(period)]), ...
    'YDir','reverse', 'layer','top', ...
    'YTick',log2(Yticks(:)), ...
    'YTickLabel',num2str(Yticks'), ...
    'layer','top','YGrid','on')
     ylabel('Period')
if nargin==4
set(gca,'Xtick',xlab.datemarks,'XTickLabel',xlab.datestring,'XGrid','on')
end

colorbar


function [WPCO,period,scale,coi,nx,sinv]=filterdata(d,I,J,dt,Args)
c=sortrows(combnk(1:size(d,2),2));
nc=size(d,2);
for i=1:size(c,1)
[wavex,period,scale,coi] = wavelet(d(:,c(i,1)),dt,Args.Pad,Args.Dj,Args.S0,Args.J1,Args.Mother);
wavey = wavelet(d(:,c(i,2)),dt,Args.Pad,Args.Dj,Args.S0,Args.J1,Args.Mother);
C{c(i,1),c(i,2)}=wavex.*conj(wavey);
C{c(i,2),c(i,1)}=conj(C{c(i,1),c(i,2)});
end
for j=1:nc
wavez = wavelet(d(:,j),dt,Args.Pad,Args.Dj,Args.S0,Args.J1,Args.Mother);
C{j,j}=abs(wavez).^2;
end

[ScaleLength,TimeLength]=size(C{1,2});
WPCO = zeros(ScaleLength,TimeLength); % Initialize WPCO
MatNum = zeros(nc-1);
MatDen1 = zeros(nc-1);
MatDen2 = zeros(nc-1);
vrows = 1:nc;
zrows = vrows;
zrows(I)=[]; 
vrows(J)=[];

CI_I = C(zrows,zrows);
CJ_I = C(vrows,zrows);
CJ_J = C(vrows,vrows);
for nscale=1:ScaleLength
    for ntime=1:TimeLength
            for iiRow=1:nc-1
                 for iiCol=1:nc-1  
                    MatAux = CJ_I{iiRow,iiCol};
                    MatNum(iiRow,iiCol) = MatAux(nscale,ntime);
                    MatAux = CI_I{iiRow,iiCol};
                    MatDen1(iiRow,iiCol) = MatAux(nscale,ntime);
                    MatAux = CJ_J{iiRow,iiCol};
                    MatDen2(iiRow,iiCol) = MatAux(nscale,ntime);
                 end
            end
            Num = det(MatNum);
            Den = abs(det(MatDen1)*det(MatDen2));                                                
            if Den > eps
                WPCO(nscale,ntime) = (-1)^(J+I)*(Num/sqrt(Den)); % Formula (39) of [1]                                     
            else
                WPCO(nscale,ntime)=0;  
            end
    end
end
sinv=1./(scale');
nx=size(d,1);


