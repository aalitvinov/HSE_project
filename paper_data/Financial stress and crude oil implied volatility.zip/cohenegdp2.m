close all
%G7_data;
gdp_ene_data;
datag=smooth_data(detrend(gdp,0),size(gdp,1));
datae=smooth_data(detrend(ene,0),size(ene,1));

nc=size(data,2);
c=combnk(1:nc,2);
weight=mean(datag);
%weight=sum(abs(data));
SumRHO=0;
SumWEIGHT=0;
figure()
for j=1:size(datag,2)
    for i=1:size(datae,2)
  [rau_rho,period,scale,coi,sig95,t]=rau13(datae(:,i),datag(:,j),'MonteCarloCount',0);  
  %[rau_rho{i},period,scale,coi,sig95{i},t]=causal(datae(:,i),datag(:,i),'MonteCarloCount',0,'Lead','xLeady');
  weighted=(weight(i)+weight(j))/sum(weight);
  weightedRHO=weighted*rau_rho;
  SumRHO = SumRHO+weightedRHO;
  SumWEIGHT=SumWEIGHT+weighted;
    end
end

Coh=SumRHO/SumWEIGHT;
%contourf(Coh,9)
rho=1;
cohesionplot(Coh,period,t,rho)
saveas(gcf,'SSAenegdpcohesion','jpg')

nc=size(data,2);
c=combnk(1:nc,2);
weight=mean(datag);
%weight=sum(abs(data));
SumRHO=0;
SumWEIGHT=0;
figure()
for j=1:size(datag,2)
    for i=1:size(datae,2)
  %[rau_rho,period,scale,coi,sig95,t]=causal(datae(:,i),datag(:,j),'MonteCarloCount',0);  
  [rau_rho,period,scale,coi,sig95,t]=causal(datae(:,i),datag(:,j),'MonteCarloCount',0,'Lead','yLeadx');
  weighted=(weight(i)+weight(j))/sum(weight);
  weightedRHO=weighted*rau_rho;
  SumRHO = SumRHO+weightedRHO;
  SumWEIGHT=SumWEIGHT+weighted;
    end
end

Coh=SumRHO/SumWEIGHT;
%contourf(Coh,9)
rho=0;
cohesionplot(Coh,period,t,rho)
saveas(gcf,'SSAenegdpcausality','jpg')


