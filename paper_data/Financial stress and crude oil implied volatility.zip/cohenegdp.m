clear all
close all
%G7_data;
gdp_ene_data;
datag=smooth_data(detrend(log(gdp),0),size(gdp,1));
datae=smooth_data(detrend(log(ene),0),size(ene,1));

nc=size(datae,2);
c=combnk(1:nc,2);
weight=mean(datag);
%weight=sum(abs(data));
SumRHO=0;
SumWEIGHT=0;
figure()
for i=1:size(datag,2)
  [rau_rho{i},period,scale,coi,sig95{i},t]=rau13(datae(:,i),datag(:,i),'MonteCarloCount',0);  
  %[rau_rho{i},period,scale,coi,sig95{i},t]=causal(datae(:,i),datag(:,i),'MonteCarloCount',0,'Lead','xLeady');
  weighted{i}=weight(i)/sum(weight);
  weightedRHO{i}=weighted{i}*rau_rho{i};
  SumRHO = SumRHO+weightedRHO{i};
  SumWEIGHT=SumWEIGHT+weighted{i};
end

Coh=SumRHO/SumWEIGHT;
%contourf(Coh,9)
rho=1;
cohesionplot(Coh,period,t,rho)
saveas(gcf,'SSAenegdpcohesion','jpg')

nc=size(datae,2);
c=combnk(1:nc,2);
weight=sum(abs(datag));
SumRHO=0;
SumWEIGHT=0;
figure()
for i=1:size(datag,2)
  [rau_rho{i},period,scale,coi,sig95{i},t]=causal(datae(:,i),datag(:,i),'MonteCarloCount',0,'Lead','xLeady');
  weighted{i}=(weight(i)+weight(i))/sum(weight);
  weightedRHO{i}=weighted{i}*rau_rho{i};
  SumRHO = SumRHO+weightedRHO{i};
  SumWEIGHT=SumWEIGHT+weighted{i};
end

Coh=SumRHO/SumWEIGHT;
%contourf(Coh,9)
rho=0;
cohesionplot(Coh,period,t,rho)
saveas(gcf,'xySSAenegdpcausality','jpg')


nc=size(datae,2);
c=combnk(1:nc,2);
weight=sum(abs(datag));
SumRHO=0;
SumWEIGHT=0;
figure()
for i=1:size(datag,2)
  [rau_rho{i},period,scale,coi,sig95{i},t]=causal(datae(:,i),datag(:,i),'MonteCarloCount',0,'Lead','yLeadx');
  weighted{i}=(weight(i)+weight(i))/sum(weight);
  weightedRHO{i}=weighted{i}*rau_rho{i};
  SumRHO = SumRHO+weightedRHO{i};
  SumWEIGHT=SumWEIGHT+weighted{i};
end

Coh=SumRHO/SumWEIGHT;
%contourf(Coh,9)
rho=0;
cohesionplot(Coh,period,t,rho)
saveas(gcf,'SSAenegdpcausality','jpg')

