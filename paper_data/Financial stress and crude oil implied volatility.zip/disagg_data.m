close all;
clear all;
addpath(genpath('C:\Users\Dr. Olayeni\Documents\myresearchfolder\LeSage'))
olofinandme;

% Type of aggregation
ta=1;   
% Minimizing the volatility of d-differenced series
d=1;
% Frequency conversion 
s=4;    
% Name of ASCII file for output
file_sal='td.sal';
Y=[]; e=[];
crange=1:2;
for i=1:size(GCF,2)
% Calling the function: output is loaded in a structure called res
res=bfl(GDP(:,i),ta,d,s);
Y=[Y res.y];
scw=cwtft(res.y(:));
scw.cfs(crange,:)=[];
scw.scales(crange)=[];
e=[e icwtft(scw)'];
end

ruacohesion(Y)
figure()
%ruacohesion(e)
ruacohesion(GCF)
ruacohesion(GDP)
ruacohesion(FDI)
rmpath(genpath('C:\Users\Dr.Olayeni\Documents\myresearchfolder\LeSage'))
