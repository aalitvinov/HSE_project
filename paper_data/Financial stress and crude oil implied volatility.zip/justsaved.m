subroutine mpwave( n, cx)       # minimum phase equivalent wavelet
integer i,         n            # input:  cx = any wavelet
complex cx(n)                   # output: cx = min phase wavelet
call ftu( 1., n, cx)            #               with same spectrum.
call scaleit( sqrt(1.*n), 2*n, cx)
do i= 1, n
        cx(i) = cx(i) * conjg( cx(i))
call kolmogoroff( n, cx)
return; end

  
subroutine kolmogoroff( n, cx)  # Spectral factorization.
integer i,              n       # input:  cx = spectrum
complex cx(n)                   # output: cx = min phase wavelet
do i= 1, n
        cx(i) = clog( cx(i) )
call ftu( -1., n, cx);          call scaleit( sqrt(1./n), 2*n, cx)
cx(1    ) = cx(1    ) / 2.
cx(1+n/2) = cx(1+n/2) / 2.
do i= 1+n/2+1, n
        cx(i) = 0.
call ftu( +1., n, cx);          call scaleit( sqrt(1.*n), 2*n, cx)
do i= 1, n
        cx(i) = cexp( cx(i))
call ftu( -1., n, cx);          call scaleit( sqrt(1./n), 2*n, cx)
return; end

