function paramEsts=jumpdiffusionestimator(x) 


function logL = mrjd_like(x,P)
%MRJD_LIKE Likelihood function of a Mean-Reverting Jump-Diffusion process.
%   LOGL = MRJD_LIKE(P,X) returns the maximum of (the negative of) 
%   the log-likelihood of a MRJD
%     dX = (alpha - beta*X)*dt + sigma*dB + N(mu,gamma)*dN(lambda) 

T = length(x);
Q=10;
alpha = P(1); beta = P(2); sigma = P(3); mu = P(4); gamma = P(5); lambda = P(6);
% (Negative of) Log-likelihood
if (lambda<2.5) & (lambda>0) & (sigma>0) & (gamma>0) & (beta>0) & (alpha>0)
    weight=poisspdf(0:Q,lambda);
    j=1;
    temp=[];
    for q = 0:Q
     temp=[temp weight(j)*normpdf( (diff(x(1:T)) - (alpha - beta*x(1:T-1) + q*mu)), 0, sqrt(q*gamma^2+sigma^2))];
     j=j+1;
    end
        logL = - sum( log(sum(temp)));
else
    logL = realmax;
end
end

T = length(x);
x = x(:);

% Preliminary estimation of the MRD part
[alpha,beta,sigma] = mrd_mle(x);

% Preliminary estimation of the jump intensity
lx = [0;diff(x)];
stdlx = std(lx);
lambda = length(find(lx > 3*stdlx)) / T;

% Initial parameters vector
P0 = [alpha,beta,sigma,alpha/beta,1,lambda];

paramEsts = mle(x, 'nloglf',@mrjd_like, 'start',P0);

end


function [alpha,beta,rho] = mrd_mle(x,dt)
%MRD_MLE Maximum likelihood estimates of a Mean-Reverting Diffusion process.
%   [ALPHA,BETA,RHO]=MRD_MLE(X,DELTA) returns parameters of a MRD process 
%   (a generalized Ornstein-Uhlenbeck type process or mean reverting 
%   Brownian motion): dX = (alpha - beta*X) * dt + rho * dB_t, with 
%   dt=DELTA (default: DELTA=1).

if nargin<2,
   dt = 1;
end;

N = length(x);
s = sum(x(1:N-1));
s2 = sum(x(1:N-1).*x(1:N-1));
sd = -sum(x(1:N-1).*diff(x));
alpha = (s2*(x(1)-x(N)) - s*sd) / (dt * (s*s - s2*(N-1)));
beta = ((x(1)-x(N)) + alpha*dt*(N-1)) / (dt*s);
rho = sqrt( sum((x(2:N) - (1-beta*dt)*x(1:N-1) - alpha*dt).^2) / (dt*(N-1)) );
end