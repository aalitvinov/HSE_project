N=100;
k=0:N/2;
alp=[0 0.2 0.4 0.6 0.8];
for alp_i=1:length(alp)
    for k_i=1:length(k)
        pk(alp_i,k_i)=(1-alp(alp_i)^2)/(1+alp(alp_i)^2-2*alp(alp_i)*cos(2*pi*k(k_i)/N));
    end
end     
    

plot(k,pk)

legend(['\alpha=' num2str(alp(1))],['\alpha=' num2str(alp(2))],...
       ['\alpha=' num2str(alp(3))],['\alpha=' num2str(alp(4))],...
       ['\alpha=' num2str(alp(5))])
