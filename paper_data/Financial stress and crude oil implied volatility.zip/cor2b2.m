function [mapar,var]=cor2b2(cor,maxiter)

%      [mapar,var]=cor2b2(cor,maxiter)
%      maxiter is put in (wordt gezet op) 3*length(cor) 
%      if maxiter is omitted (als maxiter wordt weggelaten)
%      paper
%      G.Wilson
%      Factorization of the covariance generating function
%      of a pure moving average process
%      SIAM J. Numer. Anal, vol.6, p 1-7, 1969

l=length(cor);
if nargin==1, maxiter=3*l; end;
tau=zeros(l,1);
f=zeros(l,1);
tau(1)=sqrt(cor(1)+2*sum(cor(2:l)));
iter=0;
crit=1;
lim=1e-8;

while (crit>lim&iter<maxiter),
  iter=iter+1;
  T=toeplitz([tau(1) zeros(1,l-1)],tau')+ ...
        fliplr(toeplitz([tau(l) zeros(1,l-1)],tau(l:-1:1)'));
  for i=1:l,
    f(i)=sum(tau(1:l+1-i).*tau(i:l))-cor(i);
  end
  tau=tau-T\f;
  crit=max(f);
end
var=tau(1)^2;
mapar=[1 tau(2:l)'/tau(1)];
crit=max(f);
if crit>lim,
  warning('MA-model inaccurate')
end