close all
clear all;
%G7_data;
SSA=[4 8 9 13 14 20 21 23 25 30 32 34 37 40];
ALL=1:40;
REGION=ALL;
gcf_dsav_data;
c=40;
global timeunit
timeunit=0;
%figure('name','ADF')
%waveletcoeff(GCF,DSAV,'WaveletADF')
NigeriaData;
spanish_data
[b0,n0,r0]=regress(GCF(:,c),DSAV(:,c));
%infl=[0;diff(log(CPI))];
infl=r0;
dinfl=[0;diff(infl)]; infl1=lagmatrix(infl,1); dinflags=lagmatrix(dinfl,1:4);
%dx=[dinfl(5:end) infl1(5:end) dinflags(5:end,:)];
dx=[spanish(:,1),spanish(:,3)];
[Wxx,Wyy,Wxy,C,period,scale,dt,coi,nx,sinv,Args,t]=waveletPartial(dx,1,2,'Mother','Morl0');
rec.scales=scale;

sWxy=smoothwavelet(sinv(:,ones(1,nx)).*Wxy,dt,period,Args.Dj,scale);
sY=smoothwavelet(sinv(:,ones(1,nx)).*Wxx,dt,period,Args.Dj,scale);
sX=smoothwavelet(sinv(:,ones(1,nx)).*Wyy,dt,period,Args.Dj,scale);
Rua=real(sWxy)./sqrt(sX.*sY);
Rua(sX<=1e-10)=0;
Rua(sY<=1e-10)=0;
Rsq=Rua.*sqrt(sY)./sqrt(sX);
Rsq(sX<=1e-10)=0;
contourf(real(Rsq),15)
colorbar
%[WMCO,WPCO,periods,coi]=pcoeff(GCF(:,1:3),'part',2);
%{

figure('name','ADF')
DGCF=[0;diff(DSAV(:,c))]'; GCF1=lagmatrix(DSAV(:,c),1)';
my_waveregress(DGCF(2:end),GCF1(2:end),'WaveletADF')

NigeriaData;
infl=[0;diff(log(CPI))];
dinfl=[0;diff(infl)]'; infl1=lagmatrix(infl,1)';
my_waveregress(dinfl(2:end),infl1(2:end),'WaveletADF')


China_Japan_US_Africa_data;
data=USGDP;
weight=mean(log(data)+log(GCF));

figure()
ruacohesion2(log(GDP),log(data),'Comovment')
figure()
gainfunction(log(GDP),log(data),'Gain','AntiPhase')

figure()
ruacohesion(GCF(1:end,REGION),'Capital_Movement')


figure()
gainfunction(GCF,DSAV,'Gain','AntiPhase')
figure()
gainfunction(GCF,DSAV,'Gain')

%subplot(3,1,3)
%ruacohesion(DSAV(1:end,REGION),'Saving synchronization')
%}