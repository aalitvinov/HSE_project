

Cross wavelet and wavelet coherence package  (pre-release 1)
by Aslak Grinsted, John Moore and Svetlana Jevrejeva
----------------------------------------------------

Please notice that most of the routines included in this package has the following license. 
This software may be used, copied, or redistributed as long as it is not sold and this 
copyright notice is reproduced on each copy made. This routine is provided as is without 
any express or implied warranties whatsoever.

However, not all the routines are published under these terms, and before redistributing
 them in any form we advise you to ask permission from the authors.

Acknowledgements
We would like to thank the following people for letting 
us include their programs in our package.

Torrence and Compo for CWT software. A Practical Guide to Wavelet Analysis 
Eric Breitenberger for AR1 and AR1Noise. 
Eric A. Johnson for Arrow.m. 
Blair Greenan for Colorbarf.m 


