function waverau13plot(x,y,xlab)

[Rsq,period,scale,coi,wtcsig,t]=rau13(x,y,'MonteCarlo',0);
Yticks = 2.^(fix(log2(min(period))):fix(log2(max(period))));

contourf(t,log2(period),Rsq,10);        
set(gca,'clim',[-1 1])      
set(gca,'YLim',log2([min(period),max(period)]), ...
    'YDir','reverse', 'layer','top', ...
    'YTick',log2(Yticks(:)), ...
    'YTickLabel',num2str(Yticks'), ...
    'layer','top')
     ylabel('Period')
if nargin==3
set(gca,'XTickLabel',xlab,'XGrid','on')
set(gca,'XGrid','on')
end
hold on
plot(t,log2(coi),'g','linewidth',2)
hold off
%{
%xlabel(titl)
     hold on
     if ~all(isnan(wtcsig))
        %[c,h] = contour(t,log2(period),wtcsig,[1 1],'k');%#ok
        [c,h] = contour(t,log2(period));%#ok
        set(h,'linewidth',2)
     end
     hold off
%}
%colorbar
