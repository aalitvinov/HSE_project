function CWTStruct = mycwtft(SIG,varargin)
% CWTFT Continuous wavelet transform using FFT.
%   CWTSTRUCT = CWTFT(SIG) computes the continuous wavelet 
%   transform of the signal SIG using a Fourier transform  
%   based algorithm. 
%   SIG can be a vector, a structure or a cell array.
%   If SIG is a vector, it contains the values of the signal to be
%   analyzed. If SIG is a structure, SIG.val and SIG.period contain
%   respectively the values and the sampling period of the signal.  
%   If SIG is a cell array, SIG{1} and SIG{2} contain respectively
%   the values of the signal and the sampling period.
%   By default Morlet wavelet and logarithmic scales (see SCA below)
%   are used by the algorithm.
%
%   CWTSTRUCT is a structure which contains six fields:
%      cfs:     coefficients of wavelet transform.
%      scales:  vector of scales. 
%      wav:     wavelet used for the analysis (see WAV below).
%      omega:   angular frequencies for the Fourier transform.
%      meanSIG: mean of the analyzed signal.
%      dt:      sampling period.
% 
%   CWTSTRUCT = CWTFT(SIG,'scales',SCA,'wavelet',WAV) let you 
%   define the scales or the wavelet (or both) used for the analysis.
%
%   SCA can be a vector, a structure or a cell array.
%   If SCA is a vector, it contains the scales.
%   If SCA is a structure, it may contain at most five fields
%   (s0,ds,nb,type,pow). The last two fields are optional. 
%   s0, ds and nb are respectively the smallest scale, the spacing
%   between scales and the number of scales.
%   type contains the type of scaling: 'pow' (power spacing) which  
%   is the default or 'lin' (linear spacing).
%      for 'pow' : scales = s0*pow.^((0:nb-1)*ds); 
%      for 'lin' : scales = s0 + (0:nb-1)*ds;
%   When type is 'pow', if SCA.pow exists SCA.pow = pow else 
%   pow = 2 is used as default.
%   Note that we can use only pow = 2. Indeed, we have pow^S = 2^T 
%   with T = (S*log(pow)/log(2)). So, any S power is a power T of 2. 
%
%   If SCA is a cell array, SCA{1}, SCA{2} and SCA{3} contain 
%   respectively the smallest scale, the spacing between scales 
%   and the number of scales. If SCA{4}, SCA{5} exist, then they
%   contain the type of scaling and the power (if necessary).
%   When s0 (or ds or nb) is empty the default is taken.
%
%   WAV can be a string, a structure or a cell array.
%   If WAV is a string, it contains the name of the wavelet used 
%   for the analysis.
%   If WAV is a structure, WAV.name and WAV.param are respectively 
%   the name of the wavelet and, if necessary, one or more associated
%   parameters.  
%   If WAV is a cell array, WAV{1} and WAV{2} contain the name of 
%   the wavelet and optional parameters (see CWTFTINFO for the 
%   admissible wavelets). 
%
%   Using CWTSTRUCT = CWTFT(...,'plot'), the signal and its
%   continuous wavelet transform are plotted.
%
%   See also ICWTFT, CWTFTINFO.

%   M. Misiti, Y. Misiti, G. Oppenheim, J.M. Poggi 04-Mar-2010.
%   Last Revision: 14-Mar-2011.
%   Copyright 1995-2011 The MathWorks, Inc.
%   $Revision: 1.1.6.9 $ $Date: 2011/05/13 18:28:48 $

% Check input arguments.
nbIN = nargin;
if nbIN==0 , OK_Cb = Cb_RadBTN; if OK_Cb , return; end; end
error(nargchk(1,Inf,nbIN, 'struct'))

% Signal.
if isstruct(SIG)
    val = SIG.val; dt = SIG.period;
elseif iscell(SIG)
    val = SIG{1};  dt = SIG{2};
else
    val = SIG;
end
val = val(:)';
nbSamp = length(val);

% Check other inputs.
flag_PLOT = false;
SCA = [];
ScType = ''; 
WAV = [];
pad_MODE  = 'none';
if nbIN>1
    nbArg = length(varargin);
    k = 1;
    while k<=nbArg
        ArgNAM = lower(varargin{k});
        if k<nbArg , 
            ArgVAL = varargin{k+1}; 
            if ischar(ArgVAL) , lower(ArgVAL); end
        end
        k = k+2;
        switch ArgNAM
            case 'scales'  , SCA = ArgVAL;
            case 'wavelet' , WAV = ArgVAL;
            case 'plot'    , k = k-1; flag_PLOT = true;
            case 'padmode' , pad_MODE = ArgVAL;
            otherwise
                error(message('Wavelet:FunctionInput:ArgumentName'));
        end
    end
end

% Construct time series to analyze, pad if necessary
meanSIG = mean(val);
x = val - meanSIG;
if ~isequal(pad_MODE,'none')
    np2 = 1+fix(log2(nbSamp) + 0.4999);
    x = wextend('1d',pad_MODE,x,2^np2-nbSamp,'r');
end
n = length(x);

% Check inputs to select the defaults.
%-------------------------------------
% Check sampling period
if ~exist('dt','var')
    OK_sampling_period = false;
else
    OK_sampling_period = true;
end

% Define wavelet.
if isempty(WAV) , WAV = 'morl'; end

% Define sampling period.
if ~OK_sampling_period , dt = 1; end 

% Define Scales
if isempty(SCA)
    [dum1,dum2,dum3,scales,param] = getDefaultAnalParams(WAV,n,dt);
    NbSc = length(scales);
    ScType = getScType(scales);
   
elseif isnumeric(SCA)
    [dum4,dum5,dum6,dum7,param] = getDefaultAnalParams(WAV,n,dt);
    scales = SCA;
    NbSc = length(scales);
    ScType = getScType(scales);
        
elseif isstruct(SCA) || iscell(SCA)
    if isstruct(SCA)
        s0 = SCA.s0; ds = SCA.ds; NbSc = SCA.nb;
        if ~isfield(SCA,'type')
            ScType = 'pow'; pow = 2;
        else
            ScType = SCA.type;
            switch ScType
                case 'pow'  ,
                    if isfield(SCA,'pow') ,
                        pow = SCA.pow;
                    else
                        pow = 2;
                    end
                case 'lin'
                otherwise
                    error(message('Wavelet:FunctionArgVal:Invalid_ArgVal'))
            end
        end
    else
        s0 = SCA{1}; ds = SCA{2}; NbSc = SCA{3};
        if length(SCA)<4
            ScType = 'pow'; pow = 2;
        else
            ScType = SCA{4};
            if ~isnumeric(ScType)
                switch ScType
                    case 'pow'
                        if length(SCA)>4 , pow = SCA{5}; else pow = 2; end
                    case 'lin'
                    otherwise
                        error(message('Wavelet:FunctionArgVal:Invalid_ArgVal'))
                end
            else
                pow = ScType; ScType = 'pow'; 
            end
        end
    end
    try
        [s0_def,ds_def,NbSc_def,dum9,param] = getDefaultAnalParams(WAV,n,dt);
    catch ME
        s0_def = 2*dt; ds_def = 0.25; NbSc_def = 30;
    end
    if isempty(s0) ,  s0 = s0_def;  end
    if isempty(ds) ,  ds = ds_def;   end
    if isempty(NbSc) ,NbSc = NbSc_def; end
    switch lower(ScType)
        case 'pow' , scales = s0*pow.^((0:NbSc-1)*ds);
        case 'lin' , scales = s0 + (0:NbSc-1)*ds;
    end
else
    error(message('Wavelet:FunctionInput:Argval'))
end

% Construct wavenumber array used in transform
omega = (1:fix(n/2));
omega = omega.*((2.*pi)/(n*dt));
omega = [0., omega, -omega(fix((n-1)/2):-1:1)];

% Compute FFT of the (padded) time series
f = fft(x);

% Loop through all scales and compute transform
psift  = waveft(WAV,omega,scales);
cwtcfs = ifft(repmat(f,NbSc,1).*psift,[],2);
cwtcfs = cwtcfs(:,1:nbSamp);
omega  = omega(1:nbSamp);

% Build output structure
if isstruct(WAV)
    WAV.param = param;
elseif iscell(WAV)
    WAV{2} = param;
end
CWTStruct = struct('cfs',cwtcfs,'scales',scales, ...
    'omega',omega,'meanSIG',meanSIG,'dt',dt);
CWTStruct.wav = WAV;


%----------------------------------------------------------------------
function [s0,ds,NbSc,scales,param] = getDefaultAnalParams(WAV,nbSamp,dt)

switch nargin
    case 0 , dt = 1; nbSamp = 1024; WAV = {'morl',6};
    case 1 , dt = 1; nbSamp = 1024;
    case 2 , dt = 1;
end
if isstruct(WAV)
    wname = WAV.name;
    param = WAV.param; %#ok<*NASGU>
elseif iscell(WAV)
    wname = WAV{1};
    param = WAV{2};
else
    wname = WAV;
    param = [];
end

switch wname
    case {'morl','morlex','morl0'} 
        s0 = 2*dt; ds = 0.4875; NbSc = fix(log2(nbSamp)/ds)+1;
        scales = s0*2.^((0:NbSc-1)*ds);
        if isempty(param) , param = 6; end
       
    case {'mexh','dog'}
        s0 = 2*dt;  ds = 0.4875; NbSc = max([fix(log2(nbSamp)/ds),1]);
        scales = s0*2.^((0:NbSc-1)*ds);
        if  isequal(wname,'dog') && isempty(param) , param = 2; end        
        
    case 'paul'
        s0 = 2*dt;  ds = 0.4875; NbSc = fix(log2(nbSamp)/ds)+1;
        scales = s0*2.^((0:NbSc-1)*ds);
        if isempty(param) , param = 4; end        
                
    otherwise
        s0 = 2*dt; ds = 0.25;
        NbSc = fix(log2(nbSamp)/ds)+1;
        scales = s0*2.^((0:NbSc-1)*ds);        
end
% NbSc_THEO = fix(1*log2(nbSamp)/ds)+1;
