function wavecausalplot(x,y,lead,xlab)

[Rsq,period,scale,coi,wtcsig,t]=causal(x,y,'Lead',lead,'MonteCarlo',3000);
Yticks = 2.^(fix(log2(min(period))):fix(log2(max(period))));
imagesc(t,log2(period),Rsq);%#ok       

set(gca,'clim',[0 1])      
set(gca,'YLim',log2([min(period),max(period)]), ...
    'YDir','reverse', 'layer','top', ...
    'YTick',log2(Yticks(:)), ...
    'YTickLabel',num2str(Yticks'), ...
    'layer','top','YGrid','on')
     ylabel('Period')
if nargin==4
set(gca,'Xtick',xlab.ticks,'XTickLabel',xlab.label,'XGrid','on')
set(gca,'XGrid','on')
end
%xlabel(titl)
hold on
if ~all(isnan(wtcsig))
    [c,h1] = contour(t,log2(period),wtcsig,[1 1],'w');%#ok
     set(h1,'linewidth',2)
    [c,h2] = contour(t,log2(period),wtcsig,[.9 .9],'s');%#ok
     set(h2,'linewidth',2)
plot(t,log2(coi),'g','linewidth',2)
end
hold off

%colorbar
