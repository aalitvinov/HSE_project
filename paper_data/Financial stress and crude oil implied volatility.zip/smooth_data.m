function CC =smooth_data(C,T)
t=1:T;
tt=0.25:0.25:T;
CC=[];
%Smoothing over time period
for j=1:size(C,2)
z=C(:,j);
CC=[CC spline(t,z,tt)'];
end