function varargout=mwc(x,y,z,varargin)
%% Multiple Wavelet coherence
% Creates a figure of partial cross wavelet power in units of
% normalized variance.
%
% USAGE: [Rsq,period,scale,coi,sig95]=mwc(x,y,z,[,settings])
%
% 
% Settings: Pad: pad the time series with zeros? 
% .         Dj: Octaves per scale (default: '1/12')
% .         S0: Minimum scale
% .         J1: Total number of scales
% .         Mother: Mother wavelet (default 'morlet')
% .         MaxScale: An easier way of specifying J1
% .         MakeFigure: Make a figure or simply return the output.
% .         BlackandWhite: Create black and white figures
% .         AR1: the ar1 coefficients of the series 
% .              (default='auto' using a naive ar1 estimator. See ar1nv.m)
% .         MonteCarloCount: Number of surrogate data sets in the significance calculation. (default=300)

%
% Settings can also be specified using abbreviations. e.g. ms=MaxScale.
% For detailed help on some parameters type help wavelet.
%
% Example:
%    t=1:200;
%    mwc(sin(t),sin(t.*cos(t*.01)),cos(t.*sin(t*.01)))
%

%Please acknowledge the use of this software package in any publications,
%by including text such as:
%
%   The software for the bias-rectified wavelet power spectrum, 
%   partial wavelet coherence and multiple wavelete coherence was 
%   provided by E. K. W. Ng and T. W. Kwok, which is available at:
%   http://www.cityu.edu.hk/gcacic/wavelet. 
%
%
%   (C) Eric K. W. Ng and T. K. Kowk 2012
%
% -------------------------------------------------------------------------
%
%   Copyright (C) 2012, Eric K. W. Ng and T. K. Kowk 2012
%   This software may be used, copied, or redistributed as long as it is not
%   sold and this copyright notice is reproduced on each copy made.  This
%   routine is provided as is without any express or implied warranties
%   whatsoever.
%
%---------------------------------------------------------------------------




% parse function arguments
mwcargs;

%-----------:::::::::::::--------- ANALYZE ----------::::::::::::------------

[X,period,scale,coix] = wavelet(x(:,2),dt,Args.Pad,Args.Dj,Args.S0,Args.J1,Args.Mother);%#ok
[Y,period,scale,coiy] = wavelet(y(:,2),dt,Args.Pad,Args.Dj,Args.S0,Args.J1,Args.Mother);
[Z,period,scale,coiz] = wavelet(z(:,2),dt,Args.Pad,Args.Dj,Args.S0,Args.J1,Args.Mother);
%Smooth X, Y and Z
sinv=1./(scale');


sX=smoothwavelet(sinv(:,ones(1,nx)).*(abs(X).^2),dt,period,Args.Dj,scale);
sY=smoothwavelet(sinv(:,ones(1,ny)).*(abs(Y).^2),dt,period,Args.Dj,scale);
sZ=smoothwavelet(sinv(:,ones(1,nz)).*(abs(Z).^2),dt,period,Args.Dj,scale);

% truncate X,Y,Z to common time interval 
dte=dt*.01; 
idx=find((x(:,1)>=(t(1)-dte))&(x(:,1)<=(t(end)+dte)));
X=X(:,idx);
sX=sX(:,idx);
coix=coix(idx);

idx=find((y(:,1)>=(t(1))-dte)&(y(:,1)<=(t(end)+dte)));
Y=Y(:,idx);
sY=sY(:,idx);
coiy=coiy(idx);

idx=find((z(:,1)>=(t(1))-dte)&(z(:,1)<=(t(end)+dte)));
Z=Z(:,idx);
sZ=sZ(:,idx);
coiz=coiz(idx);

coi=min(min(coix,coiy),coiz);

% -------- Cross wavelet -------
Wxy=X.*conj(Y);
Wxz=X.*conj(Z);
Wzy=Z.*conj(Y);


% ----------------------- Wavelet coherence ---------------------------------
sWxy=smoothwavelet(sinv(:,ones(1,n)).*Wxy,dt,period,Args.Dj,scale);
sWxz=smoothwavelet(sinv(:,ones(1,n)).*Wxz,dt,period,Args.Dj,scale);
sWzy=smoothwavelet(sinv(:,ones(1,n)).*Wzy,dt,period,Args.Dj,scale);

% calculate the R square value
Rsqxy=abs(sWxy).^2./(sX.*sY);
Rxy=sqrt(Rsqxy);
Rsqxz=abs(sWxz).^2./(sX.*sZ);
Rxz=sqrt(Rsqxz);
Rsqzy=abs(sWzy).^2./(sZ.*sY);
Rzy=sqrt(Rsqzy);
Rsq=(Rxy.^2+Rxz.^2-2*real(Rxy.*conj(Rxz).*conj(Rzy)))./(1-Rzy.^2);

% make figure
mwcfig;

varargout={Rsq,period,scale,coi,wtcsig};
varargout=varargout(1:nargout);






function [cout,H]=safecontourf(varargin)
vv=sscanf(version,'%i.');
if (version('-release')<14)|(vv(1)<7)
    [cout,H]=contourf(varargin{:});
else
    [cout,H]=contourf('v6',varargin{:});
end

function hcb=safecolorbar(varargin)
vv=sscanf(version,'%i.');

if (version('-release')<14)|(vv(1)<7)
    hcb=colorbar(varargin{:});
else
    hcb=colorbar('v6',varargin{:});
end

