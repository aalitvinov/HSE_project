clear
close all

%Loading the data
finstressdata
xlab={'1994','1998','2002','2006','2010'};
KCFSI=data(:,1);
WindowSmooth=3;
CNFAI=filter(ones(1,WindowSmooth)/WindowSmooth,1,data(:,2));
%set(gca,'Xtick',[50 100 150 200 250],'XTickLabel',xlab,'XGrid','on')
%% CAUSALITY IN THE SIGNALS
figure('color',[1 1 1])
set(gcf,'pos',get(gcf,'pos').*[1 .2 1.2 2])
subplot(3,1,1)
wavecausalplot(KCFSI,CNFAI,'xLeady',xlab);
xlabel('(a)  CWT causality from KCFSI to CNFAI')
subplot(3,1,2)
wavecausalplot(CNFAI,KCFSI,'xLeady',xlab);
xlabel('(b) CWT causality from CNFAI to KCFSI')
subplot(3,1,3)
waverau13plot(CNFAI,KCFSI,xlab);
xlabel('(c) Rua''s (2013) wavelet correlation')
saveas(gcf,'Causal.jpg')

%% SIGNALS
figure('color',[1 1 1])
%set(gcf,'pos',get(gcf,'pos').*[1 .2 1.2 2])
subplot(2,1,1)
plot(KCFSI)
xlabel('(a) KCFSI')
set(gca,'Xtick',[50 100 150 200 250],'XTickLabel',xlab,'XGrid','on')
axis tight
subplot(2,1,2)
plot(CNFAI)
xlabel('(b) CNFAI')
set(gca,'Xtick',[50 100 150 200 250],'XTickLabel',xlab,'XGrid','on')
axis tight
saveas(gcf,'Signals.jpg')

%% IN- and OUT-OF-PHASE CAUSALITY
figure('color',[1 1 1])
set(gcf,'pos',get(gcf,'pos').*[1 .2 1.2 2])
subplot(4,1,1)
wavecausalplot(KCFSI,CNFAI,'xLeadyInPhase',xlab);
xlabel('(a)  In-phase (positive) causal effects from KCFSI to CNFAI')
subplot(4,1,2)
wavecausalplot(CNFAI,KCFSI,'xLeadyInPhase',xlab);
xlabel('(b) In-phase (positive) causal effects from CNFAI to KCFSI')
subplot(4,1,3)
wavecausalplot(KCFSI,CNFAI,'xLeadyAntiPhase',xlab);
xlabel('(c)  Out-of-phase (negative) causal effects from KCFSI to CNFAI')
subplot(4,1,4)
wavecausalplot(CNFAI,KCFSI,'xLeadyAntiPhase',xlab);
xlabel('(d) Out-of-phase (negative) causal effects from CNFAI to KCFSI')
saveas(gcf,'CausalPhase.jpg')
