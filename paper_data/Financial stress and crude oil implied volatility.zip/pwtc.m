function [WMCO,WPCO,periods,coi] = pwtc(X,coher_type,indexP)
      
ncolsX = size(X,2);     % Number of series
C=cell(ncolsX);         % Cell array of size (ncolsX X ncolsX) to accomodate 
                        % all the complex coherency matrices
                        % e.g  C{1,2}=R12 (:=R_(X1X2))
                             
% Computation of all coherency matrices (saved in cell C)
% Formula (37) in [1]
% Compute C{1,2} first to avoid having to compute periods, scales and coi
% everytime
[WC,periods,scales,coi]=...
      wtc(X(:,1),X(:,2),'MonteCarloCount',0);%,dt,dj,lowPeriod,upPeriod,pad,mother,be,ga,...
           %wT_type,wT_size,wS_type,wS_size); %#ok<ASGLU>
                                        
[ScaleLength,TimeLength]=size(WC); 
C{1,2}=WC;
C{2,1}=conj(WC);
for iiRow=1 : ncolsX-1
    for iiCol=iiRow+1 : ncolsX
        if ~(iiCol==2)
            WC = wtc(X(:,iiRow),X(:,iiCol),'MonteCarloCount',0);%,dt,dj,lowPeriod,upPeriod,pad,...
                    %mother,be,ga,wT_type,wT_size,wS_type,wS_size);
                                        
            C{iiRow,iiCol} = WC;
            C{iiCol,iiRow} = conj(WC);
        end
    end
    C{iiRow,iiRow} = ones([ScaleLength,TimeLength]);
end    
C{ncolsX,ncolsX} = ones([ScaleLength,TimeLength]);
%
% Computation of the cell-matrix C11, obtained by deleting 1st row and 1st
% column of C; this matrix is always needed (for multiple or partial)

C11 = C(2:end,2:end); 

%%%%%%%%%%%%%%%%      MULTIPLE COHERENCY ONLY      %%%%%%%%%%%%%%%%%%%%%%%%
%                     R1^2.(2...m)
if strcmpi(coher_type,'mult') 
    WPCO=[];
    MatNum = zeros(ncolsX);
    MatDen = zeros(ncolsX-1);
    WMCO = zeros(ScaleLength,TimeLength); % Initialize WMCO
    for nscale=1:ScaleLength
        for ntime=1:TimeLength
            for iiRow=1:ncolsX
                for iiCol=1:ncolsX
                    MatAux = C{iiRow,iiCol};
                    MatNum(iiRow,iiCol) = MatAux(nscale,ntime);
                end
            end
            for iiRow=1:ncolsX-1
                for iiCol=1:ncolsX-1
                    MatAux = C11{iiRow,iiCol};
                    MatDen(iiRow,iiCol) = MatAux(nscale,ntime);
                end
            end
            WMCO(nscale,ntime)=sqrt(abs(1-abs(det(MatNum)/det(MatDen))));
                              % Formula (38) of [1]
                                                              
        end
    end
%%%%%%%%%%%%%%%%%%%    PARTIAL COHERENCY ONLY      %%%%%%%%%%%%%%%%%%%%%%     
%                     (rho_1j.(2...j-1 j+1  ...m))                    
elseif strcmpi(coher_type,'part')
    WMCO = [];
    WPCO = zeros(ScaleLength,TimeLength); % Initialize WPCO
    MatNum = zeros(ncolsX-1);
    MatDen1 = zeros(ncolsX-1);
    MatDen2 = zeros(ncolsX-1);
    vrows = 1:ncolsX;
    J=indexP; % This is just for simplicity
    vrows(J)=[];
    CJ_1 = C(vrows,2:end);
    CJ_J = C(vrows,vrows);
    for nscale=1:ScaleLength
        for ntime=1:TimeLength
            for iiRow=1:ncolsX-1
                 for iiCol=1:ncolsX-1  
                    MatAux = CJ_1{iiRow,iiCol};
                    MatNum(iiRow,iiCol) = MatAux(nscale,ntime);
                    MatAux = C11{iiRow,iiCol};
                    MatDen1(iiRow,iiCol) = MatAux(nscale,ntime);
                    MatAux = CJ_J{iiRow,iiCol};
                    MatDen2(iiRow,iiCol) = MatAux(nscale,ntime);
                 end
            end
            Num = det(MatNum);
            Den = abs(det(MatDen1)*det(MatDen2)); 
                                               
            if Den > eps
                WPCO(nscale,ntime) = (-1)^J*(Num/sqrt(Den)); 
                                    % Formula (39) of [1]                                     
            else
                WPCO(nscale,ntime)=0;  
            end
        end
    end
%%%%%%%%%%%%%       MULTIPLE and PARTIAL COHERENCIES       %%%%%%%%%%%%%%%%
elseif strcmpi(coher_type,'both')  
    MatNum = zeros(ncolsX);
    MatDen = zeros(ncolsX-1);
    WMCO = zeros(ScaleLength,TimeLength); % Initialize WMCO
    for nscale=1:ScaleLength
        for ntime=1:TimeLength
            for iiRow=1:ncolsX
                for iiCol=1:ncolsX
                    MatAux = C{iiRow,iiCol};
                    MatNum(iiRow,iiCol) = MatAux(nscale,ntime);
                end
            end
            for iiRow=1:ncolsX-1
                for iiCol=1:ncolsX-1
                    MatAux = C11{iiRow,iiCol};
                    MatDen(iiRow,iiCol) = MatAux(nscale,ntime);
                end
            end
            WMCO(nscale,ntime) = sqrt(abs(1-abs(det(MatNum)/det(MatDen))));
        end
    end
    J = indexP; % Just for simplicity
    WPCO = zeros(ScaleLength,TimeLength);
    MatNum = zeros(ncolsX-1);
    MatDen1 = zeros(ncolsX-1);
    MatDen2 = zeros(ncolsX-1);
    vrows = 1:ncolsX;
    vrows(J) = [];
    CJ_1 = C(vrows,2:end);
    CJ_J = C(vrows,vrows);
	for nscale=1:ScaleLength
        for ntime=1:TimeLength
            for iiRow=1:ncolsX-1
                for iiCol=1:ncolsX-1  
                    MatAux = CJ_1{iiRow,iiCol};
                    MatNum(iiRow,iiCol) = MatAux(nscale,ntime);
                    MatAux=C11{iiRow,iiCol};
                    MatDen1(iiRow,iiCol) = MatAux(nscale,ntime);
                    MatAux=CJ_J{iiRow,iiCol};
                    MatDen2(iiRow,iiCol) = MatAux(nscale,ntime);
                end
            end
            Num = det(MatNum);
            Den = abs(det(MatDen1)*det(MatDen2));
            if Den> eps
                 WPCO(nscale,ntime) = ((-1)^J)*(Num/sqrt(Den));       
            else
               WPCO(nscale,ntime)=0;
            end
        end
	end
else
    error('wrong coherency type')
end

end
%%%%%%%%%%%%%%%%%  END OF SUBFUNCTION MPWAVELETCOHERENCY %%%%%%%%%%%%%%%%%%
