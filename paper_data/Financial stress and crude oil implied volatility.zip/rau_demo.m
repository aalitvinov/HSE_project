%{
dataforstress
figure()
[Rsq,period,scale,coi,sig95,t]=rau13(data(:,1),data(:,2));
Yticks = 2.^(fix(log2(min(period))):fix(log2(max(period))));
contourf(t,log2(period),Rsq,12);%#ok       
set(gca,'clim',[-1 1])      
set(gca,'YLim',log2([min(period),max(period)]), ...
    'YDir','reverse', 'layer','top', ...
    'YTick',log2(Yticks(:)), ...
    'YTickLabel',num2str(Yticks'), ...
    'layer','top')
     ylabel('Period')
colorbar


%}

%% House-keeping
clear
close all
randn('seed',3)
%% Setting parameters
l=1;m=2;
a=[-0.5 0.1 0.5];
b=0;
lb=250;
ub=350;
%% Building the model
one=ones(4,1);
rho=0;
Sig=[0.01 rho;
     rho 0.001];
nobs=200;
nburns=200;
e1=mvnrnd([0 0],Sig,nobs+nburns)';
e=[e1;zeros(2,nobs+nburns)];
y1=e(:,1);

indx=0;
figure('color',[1 1 1])
for i=1:length(a);
A1=[0.1 0 0.1 0;
    0 0.1 0 0.1;
    1   0   0 0;
    0   1   0 0];
A2=[0.1 0 0.1  0;
    0 0.1 0.5 0.1;
    1   0   0 0;
    0   1   0 0];

for t = 2:nobs+nburns
%    if t<nburns
%    y1(t)=0;
%    end
    if t>=lb & t<ub
    y1(:,t)=A2*y1(:,t-1)+e(:,t);
    else 
    y1(:,t)=A1*y1(:,t-1)+e(:,t);
    end
end
data=y1(:,nobs+1:end)';
indx=indx+1;
titl=['a = ' num2str(a(i)) '; b =' num2str(b)];
%set(gcf,'pos',get(gcf,'pos').*[1 .2 1.2 2])
if indx==5,xta=1; else xta=0; end;
subplot(3,1,indx)
wavecausalplot([data(:,l)],[data(:,m)],'yLeadx',xta,titl);
%{
indx=indx+1;
if indx==5,xta=1; else xta=0; end;
%set(gcf,'pos',get(gcf,'pos').*[1 .2 1 2])
subplot(3,3,indx)
wavecausalplot([data(:,l)],[data(:,m)],'yLeadxInPhase',xta,titl);
%if indx==1,title('In-phase (postive) causal effect') ; end;

indx=indx+1;
if indx==6,xtb=1; else xtb=0; end;
subplot(3,3,indx)
wavecausalplot([data(:,l)],[data(:,m)],'yLeadxAntiPhase',xtb,titl);
%if indx==2,title('Anti-phase (negative) causal effect') ; end;
%}
end

indx=0;
figure('color',[1 1 1])
for i=1:length(a);
A1=[0.1 0 0.15 0;
    0 0.1 0 0.1;
    1   0   0 0;
    0   1   0 0];
A2=[0.1 0 0.15  0;
    0 0.1 a(i) 0.1;
    1   0   0 0;
    0   1   0 0];

for t = 2:nobs+nburns
%    if t<nburns
%    y1(t)=0;
%    end
    if t>=lb & t<ub
    y1(:,t)=A2*y1(:,t-1)+e(:,t);
    else 
    y1(:,t)=A1*y1(:,t-1)+e(:,t);
    end
end
data=y1(:,nobs+1:end)';
indx=indx+1;
titl=['a = ' num2str(a(i)) '; b =' num2str(b)];
%set(gcf,'pos',get(gcf,'pos').*[1 .2 1.2 2])
if indx==5,xta=1; else xta=0; end;
%subplot(3,1,indx)
wavecausalplot([data(:,l)],[data(:,m)],'xLeady',xta,titl);
%if indx==1,title('In-phase (postive) causal effect') ; end;
%{
indx=indx+1;
titl=['a = ' num2str(a(i)) '; b =' num2str(b)];
if indx==5,xta=1; else xta=0; end;
subplot(3,3,indx)
wavecausalplot([data(:,l)],[data(:,m)],'xLeadyInPhase',xta,titl);
%if indx==1,title('In-phase (postive) causal effect') ; end;

indx=indx+1;
if indx==6,xtb=1; else xtb=0; end;
subplot(3,3,indx)
wavecausalplot([data(:,l)],[data(:,m)],'xLeadyAntiPhase',xtb,titl);
%if indx==2,title('Anti-phase (negative) causal effect') ; end;
%}
end
%{

indx=0;
figure('color',[1 1 1])
for i=1:length(a);
A1=[0.1 0 0.15 0;
    0 0.1 0 0.1;
    1   0   0 0;
    0   1   0 0];
A2=[0.1 0 0.15  0;
    0 0.1 a(i) 0.1;
    1   0   0 0;
    0   1   0 0];

for t = 2:nobs+nburns
%    if t<nburns
%    y1(t)=0;
%    end
    if t>=lb & t<ub
    y1(:,t)=A2*y1(:,t-1)+e(:,t);
    else 
    y1(:,t)=A1*y1(:,t-1)+e(:,t);
    end
end

data=y1(:,nobs+1:end)';
indx=indx+1;
titl=['a = ' num2str(a(i)) '; b =' num2str(b)];
set(gcf,'pos',get(gcf,'pos').*[1 .2 1 2])
if indx==5,xta=1; else xta=0; end;
subplot(3,2,indx)
waverau13plot([data(:,l)],[data(:,m)],xta,titl);
%if indx==1,title('In-phase (postive) causal effect') ; end;

indx=indx+1;
if indx==6,xtb=1; else xtb=0; end;
subplot(3,2,indx)
waverau13plot([data(:,l)],[data(:,m)],xtb,titl);
%if indx==2,title('Anti-phase (negative) causal effect') ; end;
end


figure()
subplot(2,1,1)
wtc([data(:,l)],[data(:,m)],'MonteCarlo',0);
subplot(2,1,2)
xwtrec([data(:,l)],[data(:,m)]);

figure()
subplot(2,1,1)
rau13([data(:,l)],[data(:,m)],'MonteCarlo',0);
subplot(2,1,2)
xwtrec([data(:,l)],[data(:,m)]);
%}
%{
dataforstress
stress=1;ecoactivity=2;
%Compute 3-month moving average for economic activity
data(:,ecoactivity)=filter([1/3 1/3 1/3],1,data(:,ecoactivity));
mean(data)
var(data)
close all
figure('name','Financial stress and economic activity')
subplot(2,1,1)
plot(time(:),data(:,stress),'linewidth',2)
title('Financial stress')
axis tight
subplot(2,1,2)
plot(time(:),data(:,ecoactivity),'linewidth',2)
title('Economic activity')
axis tight

figure('name','Financial stress causing economic activity')
subplot(2,1,1)
causal([time(:) data(:,stress)],[time(:) data(:,ecoactivity)],'Lead','xLeadyInPhase','MonteCarlo',0);
title('(a) Positive (in-phase) causal effect')
subplot(2,1,2)
causal([time(:) data(:,stress)],[time(:) data(:,ecoactivity)],'Lead','xLeadyAntiPhase','MonteCarlo',0);
title('(b) Negative (anti-phase) causal effect')

figure('name','Economic activity causing financial stress')
subplot(2,1,1)
causal([time(:) data(:,stress)],[time(:) data(:,ecoactivity)],'Lead','yLeadxInPhase','MonteCarlo',0);
title('(a) Positive (in-phase) causal effect')
subplot(2,1,2)
causal([time(:) data(:,stress)],[time(:) data(:,ecoactivity)],'Lead','yLeadxAntiPhase','MonteCarlo',0);
title('(b) Negative (anti-phase) causal effect')

figure()
subplot(2,1,1)
wtc([time(:) data(:,1)],[time(:) data(:,2)],'MonteCarlo',0);
subplot(2,1,2)
xwtrec([time(:) data(:,1)],[time(:) data(:,2)]);

figure()
subplot(2,1,1)
rau13([time(:) data(:,1)],[time(:) data(:,2)],'MonteCarlo',0);
subplot(2,1,2)
xwtrec([time(:) data(:,1)],[time(:) data(:,2)]);
%}