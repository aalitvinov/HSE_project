function plotdecay(d1,titlen)
[P,freq]=pburg(zscore(d1),7,[],1);
aa=ar1(d1);
Ptheoretical=(1-aa.^2)./(abs(1-aa.*exp(-2*pi*1i*freq))).^2;
semilogy(freq,P/sum(P),freq,Ptheoretical/sum(Ptheoretical),'r');
legend('observed',sprintf('Theoretical AR1=%.2f',aa),'location','best')
title(titlen)
